package com.example.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class WinScreenActivity extends AppCompatActivity {

    private TextView tvText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win_screen);
        tvText = findViewById(R.id.tvText);
        Intent intent = getIntent();
        String player = intent.getStringExtra("player");
        if (player.equals("x")) {
            tvText.setText("X WON! \n Good game, \n Well played!!!");
        }
        else if (player.equals("o")) {
            tvText.setText("O WON! \n Good game, \n Well played!!!");
        }
        else if (player.equals("tie")) {
            tvText.setText("It's a TIE! \n Good game, \n Well played!!!");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_play, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.back) {
            Intent intent = new Intent(this, FirstScreenActivity.class);
            startActivity(intent);
            finish();
        }
        return true;
    }

    public void onBackPressed() {
        Intent intent = new Intent(this,FirstScreenActivity.class);
        startActivity(intent);
        finish();
    }
}