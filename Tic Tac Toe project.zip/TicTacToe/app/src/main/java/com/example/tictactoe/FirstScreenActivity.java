package com.example.tictactoe;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class FirstScreenActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton btnLeftTop, btnCenterTop, btnRightTop, btnLeftCenter, btnCenterCenter, btnRightCenter, btnLeftBottom, btnCenterBottom, btnRightBottom;
    private int turn;
    private TextView txt;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_screen);
        btnLeftTop = findViewById(R.id.b3);
        btnLeftTop.setOnClickListener(this);
        btnCenterTop = findViewById(R.id.b2);
        btnCenterTop.setOnClickListener(this);
        btnRightTop = findViewById(R.id.b1);
        btnRightTop.setOnClickListener(this);
        btnLeftCenter = findViewById(R.id.b6);
        btnLeftCenter.setOnClickListener(this);
        btnCenterCenter = findViewById(R.id.b5);
        btnCenterCenter.setOnClickListener(this);
        btnRightCenter = findViewById(R.id.b4);
        btnRightCenter.setOnClickListener(this);
        btnLeftBottom = findViewById(R.id.b9);
        btnLeftBottom.setOnClickListener(this);
        btnCenterBottom = findViewById(R.id.b8);
        btnCenterBottom.setOnClickListener(this);
        btnRightBottom = findViewById(R.id.b7);
        btnRightBottom.setOnClickListener(this);
        turn = 0; //0 == x's turn, 1 == o's turn
        txt = findViewById(R.id.txt);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_play, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.back) {
            Intent intent = new Intent(this, OpenScreenActivity.class);
            startActivity(intent);
            finish();
        }
        else if (id == R.id.reset) {
            btnLeftTop.setBackgroundResource(R.color.white);
            btnCenterTop.setBackgroundResource(R.color.white);
            btnRightTop.setBackgroundResource(R.color.white);
            btnLeftCenter.setBackgroundResource(R.color.white);
            btnCenterCenter.setBackgroundResource(R.color.white);
            btnRightCenter.setBackgroundResource(R.color.white);
            btnLeftBottom.setBackgroundResource(R.color.white);
            btnCenterBottom.setBackgroundResource(R.color.white);
            btnRightBottom.setBackgroundResource(R.color.white);
        }
        return true;
    }

    public void onBackPressed() {
        Intent intent = new Intent(this,OpenScreenActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View view) {
        char id = String.valueOf(view.getId()).charAt(String.valueOf(view.getId()).length() - 1);
        checkTaken(view);
        if (!checkWin(view, id)) {
            checkTie();
        }
        else {
            Intent intent = new Intent(this, WinScreenActivity.class);
            if (view.getTag().equals("x")) {
                intent.putExtra("player", (String) view.getTag());
            }
            else if (view.getTag().equals("o")) {
                intent.putExtra("player", (String) view.getTag());
            }
            startActivity(intent);
            finish();
        }
    }

    @SuppressLint("SetTextI18n")
    public void checkTaken(View view) {
        String tag = (String) view.getTag();
        if (tag == null) {
            view.setTag("dummy");
            tag = (String) view.getTag();
        }
        if (!(tag.equals("x") || tag.equals("o"))) {
            if (turn == 0) {
                view.setBackgroundResource(R.drawable.tic_tac_toe_x);
                view.setTag("x");
                turn = 1;
                txt.setText("O's turn");
                txt.setTextColor(this.getResources().getColor(R.color.red));
            } else if (turn == 1) {
                view.setBackgroundResource(R.drawable.tic_tac_toe_o);
                view.setTag("o");
                turn = 0;
                txt.setText("X's turn");
                txt.setTextColor(this.getResources().getColor(R.color.black));
            }
        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Illegal Move!");
            builder.setMessage("You cannot place your mark here. This spot has already been taken!");
            builder.setCancelable(true);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public boolean checkWin(View view, char id) {
        int intId = view.getId();
        String tag = (String) findViewById(intId).getTag();
        return checkRow(id, intId, tag) || checkDiagonal(id, tag) || checkColumn(id, intId, tag);
    }

    public boolean isTagEqual(int id1, int id2, String tag) {
        return findViewById(id1).getTag() != null && findViewById(id2).getTag() != null && findViewById(id1).getTag().equals(tag) && findViewById(id2).getTag().equals(tag);
    }

    public boolean checkRow(char id, int intId, String tag) {
        if ((id == '7' || id == '0' || id == '3') && isTagEqual(intId + 1, intId + 2, tag)) {
            return true;
        }
        else if ((id == '8' || id == '1' || id == '4') && isTagEqual(intId - 1, intId + 1, tag)) {
            return true;
        }
        else return (id == '9' || id == '2' || id == '5') && isTagEqual(intId - 1, intId - 2, tag);
    }

    @SuppressLint("ResourceType")
    public boolean checkDiagonal(char id, String tag) {
        if ((id == '7' || id == '1' || id == '5') && isTagEqual(R.id.b1, R.id.b9, tag) && findViewById(R.id.b5) != null && findViewById(R.id.b5).getTag().equals(tag)) {
            return true;
        } else {
            return (id == '9' || id == '1' || id == '3') && isTagEqual(R.id.b3, R.id.b7, tag) && findViewById(R.id.b5).getTag() != null && findViewById(R.id.b5).getTag().equals(tag);
        }
    }

    public boolean checkColumn(char id, int intId, String tag) {
        if ((id == '7' || id == '8' || id == '9') && isTagEqual(intId + 3, intId + 6, tag)) {
            return true;
        }
        else if ((id == '0' || id == '1' || id == '2') && isTagEqual(intId - 3, intId + 3, tag)) {
            return true;
        }
        else return (id == '3' || id == '4' || id == '5') && isTagEqual(intId - 3, intId - 6, tag);
    }

    @SuppressLint("ResourceType")
    public void checkTie() {
        if (findViewById(R.id.b1).getTag() != null && findViewById(R.id.b2).getTag() != null) {
            if (findViewById(R.id.b3).getTag() != null && findViewById(R.id.b4).getTag() != null) {
                if (findViewById(R.id.b5).getTag() != null && findViewById(R.id.b6).getTag() != null) {
                    if (findViewById(R.id.b7).getTag() != null && findViewById(R.id.b8).getTag() != null) {
                        if (findViewById(R.id.b9).getTag() != null) {
                            Intent intent = new Intent(this, WinScreenActivity.class);
                            intent.putExtra("player", "tie");
                            startActivity(intent);
                            finish();
                        }
                    }
                }
            }
        }
    }
}