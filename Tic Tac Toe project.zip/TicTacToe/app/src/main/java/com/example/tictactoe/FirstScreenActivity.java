package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstScreenActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btnLeftTop, btnCenterTop, btnRightTop, btnLeftCenter, btnCenterCenter, btnRightCenter, btnLeftBottom, btnCenterBottom, btnRightBottom;
    private int turn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_screen);
        btnLeftTop = findViewById(R.id.btnLeftTop);
        btnLeftTop.setOnClickListener(this);
        btnCenterTop = findViewById(R.id.btnCenterTop);
        btnCenterTop.setOnClickListener(this);
        btnRightTop = findViewById(R.id.btnRightTop);
        btnRightTop.setOnClickListener(this);
        btnLeftCenter = findViewById(R.id.btnLeftCenter);
        btnLeftCenter.setOnClickListener(this);
        btnCenterCenter = findViewById(R.id.btnCenterCenter);
        btnCenterCenter.setOnClickListener(this);
        btnRightCenter = findViewById(R.id.btnRightCenter);
        btnRightCenter.setOnClickListener(this);
        btnLeftBottom = findViewById(R.id.btnLeftBottom);
        btnLeftBottom.setOnClickListener(this);
        btnCenterBottom = findViewById(R.id.btnCenterBottom);
        btnCenterBottom.setOnClickListener(this);
        btnRightBottom = findViewById(R.id.btnRightBottom);
        btnRightBottom.setOnClickListener(this);
        turn = 0; //0 = x's turn, 1 = o's turn
    }


    public void btnRightBottom(View view) {
        if (!btnRightBottom.getResources().equals(R.drawable.tic_tac_toe_x) || !btnRightBottom.getResources().equals(R.drawable.tic_tac_toe_o)) {
            if (turn == 0) {
                btnRightBottom.setBackgroundResource(R.drawable.tic_tac_toe_x);
                turn = 1;
            }
            else if (turn == 1) {
                btnRightBottom.setBackgroundResource(R.drawable.tic_tac_toe_o);
                turn = 0;
            }
        }
    }

    public void btnCenterBottom(View view) {
        if (!btnCenterBottom.getResources().equals(R.drawable.tic_tac_toe_x) || !btnCenterBottom.getResources().equals(R.drawable.tic_tac_toe_o)) {
            if (turn == 0) {
                btnCenterBottom.setBackgroundResource(R.drawable.tic_tac_toe_x);
                turn = 1;
            }
            else if (turn == 1) {
                btnCenterBottom.setBackgroundResource(R.drawable.tic_tac_toe_o);
                turn = 0;
            }
        }
    }

    public void btnLeftBottom(View view) {
    }

    public void btnRightCenter(View view) {
    }

    public void btnCenterCenter(View view) {
    }

    public void btnLeftCenter(View view) {
    }

    public void btnRightTop(View view) {
    }

    public void btnCenterTop(View view) {
    }

    public void btnLeftTop(View view) {
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (!findViewById(id).getResources().equals(R.drawable.tic_tac_toe_x) || !findViewById(id).getResources().equals(R.drawable.tic_tac_toe_o)) {
            if (turn == 0) {
                findViewById(id).setBackgroundResource(R.drawable.tic_tac_toe_x);
                turn = 1;
            }
            else if (turn == 1) {
                findViewById(id).setBackgroundResource(R.drawable.tic_tac_toe_o);
                turn = 0;
            }
        }
    }
}